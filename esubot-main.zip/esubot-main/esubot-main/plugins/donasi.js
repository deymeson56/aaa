let handler = async m => m.reply(`
╭─〘 DOAÇÃO 〙
│ • KWAI : Kwai487768775
╰────
`.trim()) // Tambah sendiri kalo mau
handler.help = ['donasi']
handler.tags = ['info']
handler.command = /^dona(te|si)$/i

module.exports = handler
