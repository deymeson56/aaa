const listmenu = (prefix) => { 
	return ` *LISTA MENU BRUXINHO MODS*
	
	
╭─「 *MIDIA DOWNLOADER* 」──
├➲ *${prefix}tiktokstalk [nome]*
├➲ *${prefix}igstalk [ahmd.fdhl_]*
├➲ *${prefix}insta [Link]*
├➲ *${prefix}instastory [nome]*
├➲ *${prefix}ssweb [url]*
├➲ *${prefix}url2img [Url]*
├➲ *${prefix}tiktok*
├➲ *${prefix}fototiktok*
├➲ *${prefix}meme*
├➲ *${prefix}memeindo*
├➲ *${prefix}kbbi*
├➲ *${prefix}wait*
├➲ *${prefix}trendtwit*
├➲ *${prefix}google [últimas notícias]*
├➲ *${prefix}pinterest*
├➲ *${prefix}play [nome da música]* 
╰─────────────────────

╭────「 *FUN & GAME* 」────
├➲ *${prefix}anjing*
├➲ *${prefix}kucing*
├➲ *${prefix}testime*
├➲ *${prefix}hilih*
├➲ *${prefix}say*
├➲ *${prefix}apakah*
├➲ *${prefix}kapankah*
├➲ *${prefix}bisakah*
├➲ *${prefix}rate*
├➲ *${prefix}watak*
├➲ *${prefix}hobby*
├➲ *${prefix}infogempa*
├➲ *${prefix}infonomor*
├➲ *${prefix}quotes*
├➲ *${prefix}truth*
├➲ *${prefix}dare*
├➲ *${prefix}katabijak*
├➲ *${prefix}fakta*
├➲ *${prefix}darkjokes*
├➲ *${prefix}bucin*
├➲ *${prefix}pantun*
├➲ *${prefix}katacinta*
├➲ *${prefix}jadwaltvnow*
├➲ *${prefix}hekerbucin*
├➲ *${prefix}katailham*
├➲ *${prefix}caklontong*
├➲ *${prefix}family100*
╰─────────────────────


╭─────────────────────
├➲ *${prefix}asupan*
├➲ *${prefix}tebakgambar*
├➲ *${prefix}caklontong*
├➲ *${prefix}family100*
├➲ *${prefix}kalkulator [13*12]*
├➲ *${prefix}wp [gunung]*
╰─────────────────────


╭───「 *OUTROS & DEFACE* 」───
├➲ *${prefix}jarak [Klatem/Jogja]*
├➲ *${prefix}translate [en/Apa kabar?]*
├➲ *${prefix}pasangan [Fadhil/Salsa]*
├➲ *${prefix}gantengcek [Fadhil]*
├➲ *${prefix}cantikcek [Salsa]*
├➲ *${prefix}artinama [Fadhil]*
├➲ *${prefix}persengay [Bryan]*
├➲ *${prefix}pbucin [Fadhil]*
├➲ *${prefix}bpfont [Fadhil]*
├➲ *${prefix}textstyle [Fadhil Graphy]*
├➲ *${prefix}jadwaltv [GTV]*
├➲ *${prefix}lirik [I am lady]*
├➲ *${prefix}chord [I am lady]*
├➲ *${prefix}wiki [Adolf Hitler]*
├➲ *${prefix}brainly [pertanyaan]*
├➲ *${prefix}resepmasakan [rawon]*
├➲ *${prefix}map [Klaten]*
├➲ *${prefix}film [The Walking Death]*
├➲ *${prefix}pinterest [gambar kucing]*
├➲ *${prefix}infocuaca [Klaten]*
├➲ *${prefix}jamdunia [Indonesia]*
├➲ *${prefix}mimpi [Com ele]*
├➲ *${prefix}infoalamat [jalan Klaten]*
╰─────────────────────


╭─────────────────────
├➲ *${prefix}asupan*
├➲ *${prefix}tebakgambar*
├➲ *${prefix}caklontong*
├➲ *${prefix}family100*
├➲ *${prefix}kalkulator [13*12]*
├➲ *${prefix}wp [gunung]*
╰─────────────────────

╭─────────────────────
├➲ *${prefix}jadwalsholat [Klaten]*
├➲ *${prefix}quran*
├➲ *${prefix}quransurah [1]*
├➲ *${prefix}tafsir [1/5]*
╰─────────────────────

╭─────────────────────
├➲ *${prefix}becrypt [string]*
├➲ *${prefix}encode64 [string]*
├➲ *${prefix}decode64 [encrypt]*
├➲ *${prefix}encode32 [string]*
├➲ *${prefix}decode32 [encrypt]*
├➲ *${prefix}encbinary [string]*
├➲ *${prefix}decbinary [encrypt]*
├➲ *${prefix}encoctal [string]*
├➲ *${prefix}decoctal [encrypt]*
├➲ *${prefix}hashidentifier [Encrypt Hash]*
├➲ *${prefix}dorking [dork]*
├➲ *${prefix}pastebin [teks]*
├➲ *${prefix}tinyurl [link]*
├➲ *${prefix}bitly [link]*
╰─────────────────────

╭───「 *CRIADOR MENU* 」───
├➲ *${prefix}sticker*
├➲ *${prefix}quotemaker [tx/wtrmk/tema]*
├➲ *${prefix}nulis [nome/kelas/text]*
├➲ *${prefix}trigger [responder imagem]*
├➲ *${prefix}rip [responder imagem]*
├➲ *${prefix}wasted [responder imagem]*
├➲ *${prefix}cphlogo [Fadhil/Graphy]*
├➲ *${prefix}cglitch [Fadhil/Graphy]*
├➲ *${prefix}cpubg [Fadhil/Graphy]*
├➲ *${prefix}cml [Fadhil/Graphy]*
├➲ *${prefix}tahta [Salsa]*
├➲ *${prefix}croman [Fadhil dan Salsa]*
├➲ *${prefix}cthunder [Fadhil Graphy]*
├➲ *${prefix}cbpink [Fadhil Graphy]*
├➲ *${prefix}cmwolf [Fadhil Graphy]*
├➲ *${prefix}csky [Fadhil Graphy]*
├➲ *${prefix}cwooden [Fadhil Graphy]*
├➲ *${prefix}cflower [Fadhil Graphy]*
├➲ *${prefix}clove [Fadhil Graphy]*
├➲ *${prefix}ccrossfire [Fadhil Graphy]*
├➲ *${prefix}cnaruto [Fadhil Graphy]*
├➲ *${prefix}cparty [Fadhil Graphy]*
├➲ *${prefix}cshadow [Fadhil Graphy]*
├➲ *${prefix}cminion [Fadhil Graphy]*
├➲ *${prefix}cneon [Fadhil Graphy]*
├➲ *${prefix}cneon2 [Fadhil Graphy]*
├➲ *${prefix}cneongreen [Fadhil Graphy]*
├➲ *${prefix}c3d [Fadhil Graphy]*
├➲ *${prefix}csky [Fadhil Graphy]*
├➲ *${prefix}tts [id Haii]*
├➲ *${prefix}ttp [Fadhil Graphy]*
├➲ *${prefix}slide [Fadhil Graphy]*
├➲ *${prefix}stiker*
├➲ *${prefix}gifstiker*
├➲ *${prefix}toimg*
├➲ *${prefix}img2url*
├➲ *${prefix}nobg*
├➲ *${prefix}tomp3*
├➲ *${prefix}ocr*
╰──────────────────────

╭──────「 *SÓ GRUPO* 」───
├➲ *${prefix}modeanime [On/Off]*
├➲ *${prefix}naruto*
├➲ *${prefix}minato*
├➲ *${prefix}boruto*
├➲ *${prefix}hinata*
├➲ *${prefix}sakura*
├➲ *${prefix}sasuke*
├➲ *${prefix}kaneki*
├➲ *${prefix}toukachan*
├➲ *${prefix}rize*
├➲ *${prefix}akira*
├➲ *${prefix}itori*
├➲ *${prefix}kurumi*
├➲ *${prefix}miku*
├➲ *${prefix}anime*
├➲ *${prefix}animecry*
├➲ *${prefix}neonime*
├➲ *${prefix}animekiss*
├➲ *${prefix}wink*
╰─────────────────────

╭─────────────────────
├➲ *${prefix}welcome [On/Off]*
├➲ *${prefix}grup [buka/tutup]*
├➲ *${prefix}antilink [on/off*
├➲ *${prefix}ownergrup*
├➲ *${prefix}setpp*
├➲ *${prefix}infogc*
├➲ *${prefix}add 5511XXXXXX* 
├➲ *${prefix}kick*
├➲ *${prefix}promote*
├➲ *${prefix}demote*
├➲ *${prefix}setname*
├➲ *${prefix}setdesc*
├➲ *${prefix}linkgrup*
├➲ *${prefix}tagme*
├➲ *${prefix}hidetag*
├➲ *${prefix}tagall*
├➲ *${prefix}mentionall*
├➲ *${prefix}fitnah*
├➲ *${prefix}listadmin*
├➲ *${prefix}openanime*
├➲ *${prefix}edotense*
╰──────────────────────

╭──────────────────────
├➲ *${prefix}nsfw [On/Off]*
├➲ *${prefix}nsfwloli*
├➲ *${prefix}nsfwblowjob*
├➲ *${prefix}nsfwneko*
├➲ *${prefix}nsfwtrap*
├➲ *${prefix}hentai*
├➲ *${prefix}simih [On/Off]*
╰──────────────────────

╭────「 *SÓ O BRUXINHO PODE USAR* 」─────
├➲ *${prefix}addprem [marque o cara]*
├➲ *${prefix}removeprem [marque o cara]*
├➲ *${prefix}setppbot*
├➲ *${prefix}setreply*
├➲ *${prefix}bc*
├➲ *${prefix}bcgc*
├➲ *${prefix}ban*
├➲ *${prefix}unban*
├➲ *${prefix}block*
├➲ *${prefix}unblock*
├➲ *${prefix}clearall*
├➲ *${prefix}delete*
├➲ *${prefix}clone*
├➲ *${prefix}getses*
├➲ *${prefix}leave*
╰──────────────────────


╭─────「 *SOMENTE PREMIUM* 」───
├➲ *${prefix}playmp3 [Eu sou senhora]*
├➲ *${prefix}fb [link video]*
├➲ *${prefix}snack [link snack video]*
├➲ *${prefix}ytmp3 [link yt]*
├➲ *${prefix}ytmp4 [link yt]*
├➲ *${prefix}joox [Monolog Pamungkas]*
├➲ *${prefix}smule [Link Video Smule]*
├➲ *${prefix}cersex*
├➲ *${prefix}asupan*
├➲ *${prefix}xxx [Japão]*
├➲ *${prefix}pornhub [GangBang]*
├➲ *${prefix}hentai [Random]*
├➲ *${prefix}ban [TagUser]*
├➲ *${prefix}unban [TagUser]*
├➲ *${prefix}bc [texto]*
├➲ *${prefix}asupan*
╰──────────────────────

	
               *© TEKASHI MODS*
╲    ╱    ● ᏴϴͲ●ᎷᎬΝႮ●
       ╱▔▔▔▔▔╲       Autor    : TEKASHI BOT
      ┃┈▇┈┈▇┈┃      
╭╮┣━━━━━━┫╭╮    
┃┃┃┈┈┈┈┈┈┃┃┃    
╰╯┃┈┈┈┈┈┈┃╰╯
      ╰┓┏━━┓┏╯
         ╰╯      ╰╯`
	}
exports.listmenu = listmenu
