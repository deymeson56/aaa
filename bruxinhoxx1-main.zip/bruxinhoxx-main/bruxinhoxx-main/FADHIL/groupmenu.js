const groupmenu = (prefix) => { 
	return `
╭───「 *GRUPO MENU* 」───
│
├➲ *${prefix}modeanime [On/Off]*
├➲ *${prefix}naruto*
├➲ *${prefix}minato*
├➲ *${prefix}boruto*
├➲ *${prefix}hinata*
├➲ *${prefix}sakura*
├➲ *${prefix}sasuke*
├➲ *${prefix}kaneki*
├➲ *${prefix}toukachan*
├➲ *${prefix}rize*
├➲ *${prefix}akira*
├➲ *${prefix}itori*
├➲ *${prefix}kurumi*
├➲ *${prefix}miku*
├➲ *${prefix}anime*
├➲ *${prefix}animecry*
├➲ *${prefix}neonime*
├➲ *${prefix}animekiss*
├➲ *${prefix}wink*
├➲ *${prefix}welcome [On/Off]*
├➲ *${prefix}grup [buka/tutup]*

├➲ *${prefix}ownergrup*
├➲ *${prefix}setpp*
├➲ *${prefix}infogc*
├➲ *${prefix}add 5511XXXXXX*
├➲ *${prefix}kick [marque o fdp*
├➲ *${prefix}promote [marque o fdp*
├➲ *${prefix}demote [marque o fdp*
├➲ *${prefix}setname*
├➲ *${prefix}setdesc*
├➲ *${prefix}linkgrup*
├➲ *${prefix}tagme*
├➲ *${prefix}hidetag*
├➲ *${prefix}tagall*
├➲ *${prefix}mentionall*
├➲ *${prefix}fitnah*
├➲ *${prefix}listadmin*
├➲ *${prefix}openanime*
├➲ *${prefix}edotense*
├➲ *${prefix}nsfw [On/Off]*
├➲ *${prefix}nsfwloli*
├➲ *${prefix}nsfwblowjob*
├➲ *${prefix}nsfwneko*
├➲ *${prefix}nsfwtrap*
├➲ *${prefix}hentai*
├➲ *${prefix}simih [On/Off]*
│
╰────────────────────
	
           *© TEKASHI MODS*
╲    ╱    ● ᏴϴͲ●ᎷᎬΝႮ●
       ╱▔▔▔▔▔╲       Autor    : TEKASHI BOT
      ┃┈▇┈┈▇┈┃      
╭╮┣━━━━━━┫╭╮    
┃┃┃┈┈┈┈┈┈┃┃┃    
╰╯┃┈┈┈┈┈┈┃╰╯
      ╰┓┏━━┓┏╯
         ╰╯      ╰╯`
	}
exports.groupmenu = groupmenu
