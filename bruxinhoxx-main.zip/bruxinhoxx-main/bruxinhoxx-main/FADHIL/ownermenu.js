const ownermenu = (prefix) => { 
	return ` 
	
╭──「 *SÓ O TEKASHI PODE USAR* 」───
│
├➲ *${prefix}addprem [mentioned]*
├➲ *${prefix}removeprem [mention]*
├➲ *${prefix}setppbot*
├➲ *${prefix}setreply*
├➲ *${prefix}bc*
├➲ *${prefix}bcgc*
├➲ *${prefix}ban*
├➲ *${prefix}unban*
├➲ *${prefix}block*
├➲ *${prefix}unblock*
├➲ *${prefix}clearall*
├➲ *${prefix}delete*
├➲ *${prefix}clone*
├➲ *${prefix}getses*
├➲ *${prefix}leave*
│
╰──────────────────
	
*© TEKASHI MODS*
● ᏴϴͲ ᎷᎬΝႮ ●
Autor    : TEKASHI BOT`
	}
exports.ownermenu = ownermenu
