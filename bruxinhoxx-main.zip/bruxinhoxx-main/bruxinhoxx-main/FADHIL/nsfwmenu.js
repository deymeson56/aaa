const nsfwmenu = (prefix) => { 
	return ` 
╭─────「 *NSFW MENU* 」───
│
├➲ *${prefix}playmp3 [eu sou senhora]*
├➲ *${prefix}fb [link video]*
├➲ *${prefix}snack [link snack video]*
├➲ *${prefix}ytmp3 [link yt]*
├➲ *${prefix}ytmp4 [link yt]*
├➲ *${prefix}joox [Monolog Pamungkas]*
├➲ *${prefix}smule [Link Video Smule]*
├➲ *${prefix}cersex*
├➲ *${prefix}asupan*
├➲ *${prefix}xxx [Japão]*
├➲ *${prefix}pornhub [madrasta]*
├➲ *${prefix}hentai [Random]*
├➲ *${prefix}ban [TagUser]*
├➲ *${prefix}unban [Tag do fdp]*
├➲ *${prefix}bc [texto]*
├➲ *${prefix}asupan*
│
╰────────────────────

*© TEKASHI MODS*
● ᏴϴͲ ᎷᎬΝႮ ●
Autor    : TEKASHI BOT`
	}
exports.nsfwmenu = nsfwmenu
