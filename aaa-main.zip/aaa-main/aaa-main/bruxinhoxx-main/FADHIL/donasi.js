const donasi = (Ig, name) => { 
	return `       
┏━━━━━━━━━━━━━━━━━━━━
┃          𝗗𝗢𝗡𝗔𝗦𝗜  
┣━━━━━━━━━━━━━━━━━━━━
┣━⊱ *DOAR o mais rápido possível:)* ❉⊰━━✿
┃  
┣━⊱ *KWAI*
┣⊱ Kwai487768775
┃
┣━━━━━━━━━━━━━━━━━━━━
┃  *BOT BY TEKASHI*
┗━━━━━━━━━━━━━━━━━━━━
Note:
Obrigado:)

SUBSTITUIÇÃO DE DOAÇÃO !!!
https://youtube.com/channel/UCbwIr6GYFH-Sq1QCfmbJiuA
${Ig}

`
}

exports.donasi = donasi
