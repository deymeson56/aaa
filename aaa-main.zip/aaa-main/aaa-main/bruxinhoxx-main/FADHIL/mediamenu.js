const mediamenu = (prefix) => { 
	return `
╭─「 *MIDIA DOWNLOADER* 」──
│
├➲ *${prefix}tiktokstalk [Nome]*
├➲ *${prefix}igstalk [@ahmd.fdhl_]*
├➲ *${prefix}insta [Link]*
├➲ *${prefix}instastory [Nome]*
├➲ *${prefix}ssweb [url]*
├➲ *${prefix}url2img [Url]*
├➲ *${prefix}tiktok*
├➲ *${prefix}fototiktok*
├➲ *${prefix}meme*
├➲ *${prefix}memeindo*
├➲ *${prefix}kbbi*
├➲ *${prefix}wait*
├➲ *${prefix}trendtwit*
├➲ *${prefix}google [últimas notícias]*
├➲ *${prefix}pinterest*
├➲ *${prefix}play*
│
╰──────────────────────
	
*© TEKASHI MODS*
● ᏴϴͲ ᎷᎬΝႮ ●
Autor    : TEKASHI BOT`
	}
exports.mediamenu = mediamenu
